//
//  PlantData.swift
//  Planter
//
//  Created by Mckenna Brewer on 3/17/21.
//

import Foundation
import FirebaseFirestoreSwift

struct Plant: Codable, Identifiable{
    @DocumentID var id: String?
    var careLevel: String
    var name: String
    var scientificName: String
    var sun: String
    var water: String
}


