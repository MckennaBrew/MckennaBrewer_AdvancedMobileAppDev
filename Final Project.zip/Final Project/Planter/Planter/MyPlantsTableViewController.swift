//
//  MyPlantsTableViewController.swift
//  Planter
//
//  Created by Mckenna Brewer on 3/17/21.
//

import UIKit

class MyPlantsTableViewController: UITableViewController {
    
    var myPlants = [Plant]()
    var plantDataHandler = PlantDataHandler()
    
    // will need userID to get in here somehow so we can add and delete plants from a specific users collection
    var userID = String()
    
    var signedIn = false
    
    override func viewDidAppear(_ animated: Bool) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        userID = appDelegate.userID
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        userID = appDelegate.userID
        
        plantDataHandler.onMyDataUpdate = {[weak self] (data:[Plant]) in self?.render()}
        plantDataHandler.dbSetup(userID: userID)

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        //self.navigationItem.leftBarButtonItem = self.editButtonItem
    }
    
    func render(){
        myPlants = plantDataHandler.getMyPlants()
        
        //reload the table data
        tableView.reloadData()
    }
    
    
    @IBAction func unwindSegue(_ segue: UIStoryboardSegue){
        if segue.identifier == "doneSegue"{
            let source = segue.source as! AddPlantViewController
            if source.plantName.isEmpty == false {
                plantDataHandler.addPlant(name: source.plantName, scientificName: source.plantScience, water: source.plantSun, sun: source.plantWater, careLevel: source.plantCare, userID: userID)
                
            }
        }
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return myPlants.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)

        // Configure the cell...
        
        let plant = myPlants[indexPath.row]
        cell.textLabel!.text = plant.name

        return cell
    }
    

    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    

    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            if let plantID = myPlants[indexPath.row].id {
                plantDataHandler.deletePlant(plantID: plantID, userID: userID)
            }
            //tableView.deleteRows(at: [indexPath], with: .fade)
            
        }
        else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    
    
    // sends correct book data to new table view when a genre is selected
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail" {
            let plantDetailVC = segue.destination as! DetailViewController
                if let indexPath = tableView.indexPath(for: (sender as? UITableViewCell)!) {
                    //sets the data for the destination controller
                    plantDetailVC.plantName = myPlants[indexPath.row].name
                    plantDetailVC.plantScience = myPlants[indexPath.row].scientificName
                    plantDetailVC.plantSun = myPlants[indexPath.row].sun
                    plantDetailVC.plantWater = myPlants[indexPath.row].water
                    plantDetailVC.plantCare = myPlants[indexPath.row].careLevel
            }
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
