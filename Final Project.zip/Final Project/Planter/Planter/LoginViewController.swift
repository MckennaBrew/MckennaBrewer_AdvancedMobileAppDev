//
//  LoginViewController.swift
//  Planter
//
//  Created by Mckenna Brewer on 4/15/21.
//

import UIKit
//import FirebaseUI

class LoginViewController: UIViewController {
    

    @IBOutlet weak var usernameText: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "loginSegue" {
            let plantHomeVC = segue.destination as! HomeViewController
            plantHomeVC.userID = usernameText.text!
        }
    }

}
