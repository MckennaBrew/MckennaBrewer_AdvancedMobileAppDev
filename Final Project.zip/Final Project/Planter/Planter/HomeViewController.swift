//
//  ViewController.swift
//  Planter
//
//  Created by Mckenna Brewer on 3/16/21.
//

import UIKit

class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var wateringTableView: UITableView!
    
    @IBOutlet weak var plantFactLabel: UILabel!
    
    var myPlants = [Plant]()
    var plantDataHandler = PlantDataHandler()
    
    var userID = String()
    
    var signedIn = false
    
    
    var plantFacts = ["An average sized tree can provide enough wood to make 170,100 pencils.",
                      "The first type of aspirin, painkiller and fever reducer came from the tree bark of a willow tree.",
                      "85% of plant life is found in the ocean.",
                      "Bananas contain a natural chemical which can make people feel happy.",
                      "The Amazon rainforest produces half the world’s oxygen supply.",
                      "Dendrochronology is the science of calculating a tree’s age by its rings.",
                      "Peaches, Pears, apricots, quinces, strawberries, and apples are all members of the rose family.",
                      "Apple, potatoes and onions have the same taste, to test this eat them with your nose closed.",
                      "The tallest tree ever was an Australian eucalyptus – In 1872 it was measured at 435 feet tall.",
                      "The first potatoes were cultivated in Peru about 7,000 years ago!",
                      "The evaporation from a large oak or beech tree is from ten to twenty-five gallons in twenty-four hours.",
                      "Strawberry is the only fruit that bears its seeds on the outside. The average strawberry has 200 seeds.",
                      "Leaving the skin on potatoes while cooking is healthier as all the vitamins are in the skin.",
                      "Around 2000 different types of plants are used by humans to make food.",
                      "Small pockets of air inside cranberries cause them to bounce and float in water.",
                      "Bamboo is the fastest-growing woody plant in the world; it can grow 35 inches in a single day.",
                      "A sunflower looks like one large flower, but each head is composed of hundreds of tiny flowers called florets, which ripen to become the seeds.",
                      "The California redwood (coast redwood and giant sequoia) are the largest living organisms in the world.",
                     "Ginkgo (Ginkgo biloba) is one of the oldest living tree species, it dates back to about 250 million years ago.",
                      "The first certified botanical garden was founded by Pople Nicholas III in the Vatican City in 1278 AD.",
                      "There are over 300,000 identified plant species and the list is growing all the time.",
                      "During the 1600s, tulips were so valuable in Holland that their bulbs were worth more than gold. The craze was called tulip mania and caused the crash of the Dutch economy.",
                      "The baobab tree found in Africa can store 1,000 to 120,000 litres of water in its swollen trunk.",
                      "Oak trees don’t produce acorns until they are 50 years old."]
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        generateFact()
        
        //plantDataHandler.onMyDataUpdate = {[weak self] (data:[Plant]) in self?.render()}
        //plantDataHandler.dbSetup()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        userID = appDelegate.userID
    }
    
    func render(){
        myPlants = plantDataHandler.getMyPlants()
        //reload the table data
        wateringTableView.reloadData()
    }
    
    func generateFact(){
        let randomIndex = Int.random(in: 0...23)
        
        let fact = plantFacts[randomIndex]
        
        plantFactLabel.text = "Fun Fact: \(fact)"
    }
    
    @IBAction func login(_ sender: Any) {
        if signedIn == false{
            let signInAlert = UIAlertController(title: "Login", message: "enter username to view plants", preferredStyle: .alert)
            signInAlert.addTextField(configurationHandler: {(UITextField) in })
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            signInAlert.addAction(cancelAction)
            
            let loginAction = UIAlertAction(title: "Login", style: .default, handler: { [self](UIAlertAction)in
                let userName = signInAlert.textFields![0]
                self.userID = userName.text!
                
                let appDelegate = UIApplication.shared.delegate as! AppDelegate
                appDelegate.userID = userID
                
                // check if in database already and act accordingly
                self.plantDataHandler.checkUser(userID: self.userID)
                
                self.plantDataHandler.onMyDataUpdate = {[weak self] (data:[Plant]) in self?.render()}
                self.plantDataHandler.dbSetup(userID: self.userID)
                
            })
            
            signInAlert.addAction(loginAction)
            
            present(signInAlert, animated: true, completion: nil)
            
            signedIn = true
        }
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myPlants.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "waterIdentifier", for: indexPath)

        let plant = myPlants[indexPath.row]
        cell.textLabel!.text = plant.name + " - " +  plant.water

        return cell
    }


}

