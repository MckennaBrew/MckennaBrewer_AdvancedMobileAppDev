//
//  PlantDataHandler.swift
//  Planter
//
//  Created by Mckenna Brewer on 3/17/21.
//

import Foundation
import FirebaseFirestore
import FirebaseFirestoreSwift

class PlantDataHandler{
    
    // so, the 'plants' collection contains a users plants
    // the 'all_plants" collection contains a list of all plants, and is used to provide a quiz answer and to display what plant to add in the add plants screen
    
    let db = Firestore.firestore()
    
    var allPlantData = [Plant]()
    
    var myPlantData = [Plant]()
    
    var plantLevelData = [Plant]()
    
    // need a closure for both data sets
    var onMyDataUpdate: ((_ data: [Plant]) -> Void)?
    var onAllDataUpdate: ((_ data: [Plant]) -> Void)?
    
    
    // need two functions for database setup
    // one for when a userID is needed
    // other for when just accesing all plants
    
    func dbSetupAll(){
        db.collection("all_plants") // data call for my plants
            .addSnapshotListener {querySnapshot, error in
                guard let documents = querySnapshot?.documents else {
                    print("Error fetching snapshot results: \(error!)")
                    return
                }
                self.allPlantData = documents.compactMap {document-> Plant? in
                    return try? document.data(as: Plant.self)
                }
                //passing the results to the onDataUpdate closure
                self.onAllDataUpdate?(self.allPlantData)
            }
    }
    
    func dbSetup(userID: String){
        db.collection("users").document(userID).collection("plants") // data call for a users plants
            .addSnapshotListener {querySnapshot, error in
                guard let documents = querySnapshot?.documents else {
                    print("Error fetching snapshot results: \(error!)")
                    return
                }
                self.myPlantData = documents.compactMap {document-> Plant? in
                    return try? document.data(as: Plant.self)
                }
                //passing the results to the onDataUpdate closure
                self.onMyDataUpdate?(self.myPlantData)
            }
    }
    
    
    
    // add and delete plants from myPlantData
    
    func addPlant(name: String, scientificName: String, water: String, sun: String, careLevel: String, userID: String){
        let myPlantCollection = db.collection("users").document(userID).collection("plants")
        
        let newPlantDict = ["name": name, "scientificName": scientificName, "water": water, "sun": sun, "careLevel": careLevel]
        
        var ref: DocumentReference? = nil
        
        ref = myPlantCollection.addDocument(data: newPlantDict){ err in
            if let err = err {
                print("Error adding document: \(err)")
            } else {
                print("Document added with ID: \(ref!.documentID)")
            }
        }
    }
    
    func deletePlant(plantID: String, userID: String){
        db.collection("users").document(userID).collection("plants").document(plantID).delete() { err in
            if let err = err {
                print("Error removing document: \(err)")
            } else {
                print("Document successfully removed!")
            }
        }
    }
    
    // retrieve my Plant Data
    func getMyPlants() -> [Plant] {
        return myPlantData
    }
    
    // retrieve all Plant Data
    func getAllPlants() -> [Plant] {
        return allPlantData
    }
    
    func getLevelPlants(careLevel: String) -> [Plant]{
    
        for i in 0...allPlantData.count - 1{
            if allPlantData[i].careLevel == careLevel{
                plantLevelData.append(allPlantData[i])
                print(allPlantData[i].name)
            }
        }
        
        return plantLevelData
    }
    
    
    // check if a user is in the database already or not
    func checkUser(userID: String){
        let docRef = db.collection("users").document(userID)
        
        docRef.getDocument { (document, error) in
            if let document = document, document.exists {
                //let dataDescription = document.data().map(String.init(describing:)) ?? "nil"
                print("User exists")
                
            }
            else {
                print("User does not exist")
                // add new user to the the users collection
                //db.collection("users").document(userID).collection("plants")
                //addUser(userID: userID)
            }
        }
    }
    
}
