//
//  DetailViewController.swift
//  Planter
//
//  Created by Mckenna Brewer on 4/16/21.
//

import UIKit

class DetailViewController: UIViewController {
    
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var scienceLabel: UILabel!
    @IBOutlet weak var sunLabel: UILabel!
    @IBOutlet weak var waterLabel: UILabel!
    @IBOutlet weak var careLabel: UILabel!
    
    var plantName: String = ""
    var plantScience: String = ""
    var plantSun: String = ""
    var plantWater: String = ""
    var plantCare: String = ""
    

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        nameLabel.text = plantName
        scienceLabel.text = plantScience
        sunLabel.text = plantSun
        waterLabel.text = plantWater
        careLabel.text = plantCare
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
